const httpLogger = require('./morgan');

module.exports = {
  httpLogger,
};